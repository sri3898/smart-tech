import React from 'react';
import { Product } from '../types';
import { useShop } from '../context/ShopContext';
import { Plus, Minus } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart, updateQuantity, removeFromCart, cart, navigate } = useShop();
  
  const cartItem = cart.find(item => item.id === product.id);
  const quantity = cartItem ? cartItem.quantity : 0;

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
  };

  const handleIncrement = (e: React.MouseEvent) => {
    e.stopPropagation();
    updateQuantity(product.id, 1);
  };

  const handleDecrement = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (quantity === 1) {
      removeFromCart(product.id);
    } else {
      updateQuantity(product.id, -1);
    }
  };

  return (
    <div 
      className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer flex flex-col h-full"
      onClick={() => navigate('PRODUCT_DETAIL', { productId: product.id })}
    >
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
        {product.originalPrice && (
          <div className="absolute top-2 left-2 bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded-full">
            {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
          </div>
        )}
      </div>
      
      <div className="p-3 flex flex-col flex-grow">
        <div className="flex-grow">
          <p className="text-gray-500 text-xs mb-1 font-medium">{product.weight}</p>
          <h3 className="font-semibold text-gray-800 text-sm sm:text-base leading-tight mb-2 line-clamp-2">
            {product.name}
          </h3>
        </div>
        
        <div className="mt-auto">
          <div className="flex items-center gap-2 mb-3">
             <span className="font-bold text-gray-900">₹{product.price}</span>
             {product.originalPrice && (
               <span className="text-gray-400 text-sm line-through">₹{product.originalPrice}</span>
             )}
          </div>

          {quantity === 0 ? (
            <button 
              onClick={handleAdd}
              className="w-full py-2 border border-green-600 text-green-600 font-bold rounded-lg hover:bg-green-50 transition-colors text-sm uppercase"
            >
              Add
            </button>
          ) : (
            <div className="flex items-center justify-between bg-green-600 rounded-lg text-white px-2 py-1.5">
              <button onClick={handleDecrement} className="p-1 hover:bg-green-700 rounded"><Minus size={16} /></button>
              <span className="font-bold text-sm">{quantity}</span>
              <button onClick={handleIncrement} className="p-1 hover:bg-green-700 rounded"><Plus size={16} /></button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};