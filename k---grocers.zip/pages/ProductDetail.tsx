import React from 'react';
import { useShop } from '../context/ShopContext';
import { Star, ShoppingCart, ArrowLeft, Clock } from 'lucide-react';

export const ProductDetail: React.FC = () => {
  const { route, products, addToCart, navigate } = useShop();
  const productId = route.params?.productId;
  
  const product = products.find(p => p.id === productId);

  if (!product) return <div>Product not found</div>;

  return (
    <div className="max-w-4xl mx-auto">
      <button 
        onClick={() => navigate('HOME')}
        className="flex items-center text-gray-500 hover:text-gray-900 mb-6 transition-colors"
      >
        <ArrowLeft size={20} className="mr-1" /> Back
      </button>

      <div className="bg-white rounded-2xl p-6 md:p-8 shadow-sm border border-gray-100 flex flex-col md:flex-row gap-8">
        <div className="w-full md:w-1/2">
           <div className="aspect-square bg-gray-50 rounded-xl overflow-hidden border border-gray-100">
             <img src={product.image} alt={product.name} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
           </div>
        </div>
        
        <div className="w-full md:w-1/2 flex flex-col">
           <div className="mb-1">
             <span className="text-green-600 font-bold text-xs tracking-wider uppercase bg-green-50 px-2 py-1 rounded">{product.category}</span>
           </div>
           <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
           <p className="text-gray-500 mb-4">{product.weight}</p>
           
           <div className="flex items-center gap-4 mb-6">
             <div className="flex items-center bg-green-50 px-2 py-1 rounded">
               <span className="font-bold text-green-700">{product.rating}</span>
               <Star size={14} className="text-green-700 fill-current ml-1" />
             </div>
             <span className="text-gray-400 text-sm">{product.reviews} reviews</span>
           </div>

           <div className="flex items-center gap-3 mb-8">
              <span className="text-3xl font-bold text-gray-900">₹{product.price}</span>
              {product.originalPrice && (
                 <span className="text-xl text-gray-400 line-through decoration-2">₹{product.originalPrice}</span>
              )}
              {product.originalPrice && (
                <span className="bg-blue-100 text-blue-700 font-bold text-xs px-2 py-1 rounded-full">
                  {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                </span>
              )}
           </div>

           <div className="prose text-gray-600 text-sm mb-8">
             <h3 className="font-bold text-gray-900 mb-2">Description</h3>
             <p>{product.description}</p>
           </div>

           <div className="flex items-center gap-2 text-xs text-gray-500 mb-6 bg-gray-50 p-3 rounded-lg">
             <Clock size={16} />
             <span>Delivered in <strong>10 minutes</strong></span>
           </div>

           <div className="mt-auto">
             <button 
               onClick={() => addToCart(product)}
               className="w-full bg-green-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
             >
               <ShoppingCart />
               Add to Cart
             </button>
           </div>
        </div>
      </div>
    </div>
  );
};