import React, { useState } from 'react';
import { generateRecipe } from '../services/geminiService';
import { RecipeResponse } from '../types';
import { Sparkles, ChefHat, ShoppingCart, Loader2 } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const AIChef: React.FC = () => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [recipe, setRecipe] = useState<RecipeResponse | null>(null);
  const { products, addToCart, navigate } = useShop();

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setRecipe(null);
    const result = await generateRecipe(query);
    setRecipe(result);
    setLoading(false);
  };

  // Heuristic matching to find products in store based on ingredient names
  const findMatchingProduct = (ingredient: string) => {
    // Simple partial match
    const match = products.find(p => 
      ingredient.toLowerCase().includes(p.name.toLowerCase()) || 
      p.name.toLowerCase().includes(ingredient.toLowerCase())
    );
    return match;
  };

  const handleAddIngredient = (ingredient: string) => {
    const match = findMatchingProduct(ingredient);
    if (match) {
      addToCart(match);
      alert(`Added ${match.name} to cart!`);
    } else {
      alert(`Sorry, we don't have "${ingredient}" in stock specifically.`);
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="text-center mb-8">
        <div className="inline-block p-3 bg-purple-100 text-purple-600 rounded-full mb-4">
          <Sparkles size={32} />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">AI Chef Assistant</h1>
        <p className="text-gray-600 mt-2">Tell me what you feel like eating or what ingredients you have.</p>
      </div>

      <form onSubmit={handleGenerate} className="mb-8 relative">
        <input 
          type="text" 
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="e.g., 'Spicy pasta for dinner', 'Something with potatoes and onions'..."
          className="w-full p-5 pr-16 rounded-2xl border border-gray-200 shadow-lg focus:ring-2 focus:ring-purple-500 outline-none text-lg"
        />
        <button 
          type="submit"
          disabled={loading}
          className="absolute right-3 top-3 bottom-3 bg-purple-600 text-white px-6 rounded-xl font-bold hover:bg-purple-700 disabled:bg-gray-300 transition-colors"
        >
          {loading ? <Loader2 className="animate-spin" /> : 'Ask'}
        </button>
      </form>

      {recipe && (
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 animate-fade-in">
          <div className="bg-purple-600 p-6 text-white">
             <h2 className="text-2xl font-bold flex items-center gap-2">
               <ChefHat /> {recipe.recipeName}
             </h2>
             <p className="text-purple-100 mt-2">{recipe.description}</p>
          </div>

          <div className="p-6 grid md:grid-cols-2 gap-8">
            <div>
               <h3 className="font-bold text-gray-900 mb-4 uppercase tracking-wide text-sm">Ingredients</h3>
               <ul className="space-y-3">
                 {recipe.ingredients.map((ing, idx) => {
                   const inStock = findMatchingProduct(ing);
                   return (
                     <li key={idx} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg group hover:bg-gray-100 transition-colors">
                       <span className="text-gray-700">{ing}</span>
                       {inStock && (
                         <button 
                           onClick={() => handleAddIngredient(ing)}
                           className="text-green-600 p-1 hover:bg-green-100 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                           title={`Add ${inStock.name} to cart`}
                         >
                           <ShoppingCart size={18} />
                         </button>
                       )}
                     </li>
                   );
                 })}
               </ul>
            </div>
            
            <div>
              <h3 className="font-bold text-gray-900 mb-4 uppercase tracking-wide text-sm">Instructions</h3>
              <ol className="space-y-4">
                {recipe.instructions.map((step, idx) => (
                  <li key={idx} className="flex gap-4">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-xs font-bold mt-0.5">
                      {idx + 1}
                    </span>
                    <p className="text-gray-600 text-sm leading-relaxed">{step}</p>
                  </li>
                ))}
              </ol>
            </div>
          </div>
          <div className="p-4 bg-gray-50 text-center border-t border-gray-100">
            <button onClick={() => navigate('CART')} className="text-purple-600 font-bold text-sm hover:underline">
              View Cart & Checkout
            </button>
          </div>
        </div>
      )}
    </div>
  );
};