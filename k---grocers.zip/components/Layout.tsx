import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { Category, RouteName } from '../types';
import { ShoppingCart, Search, Menu, Sparkles, X, Phone, Mail, Instagram } from 'lucide-react';

// Custom Logo Component representing the K-Grocers brand
const BrandLogo = () => (
  <svg width="42" height="42" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0">
    {/* Carrot */}
    <path d="M24 18 C24 18 28 18 30 22 L26 36 L20 34 L24 18 Z" fill="#F97316" />
    <path d="M22 16 L26 18" stroke="#166534" strokeWidth="2" strokeLinecap="round" />
    
    {/* Apple */}
    <circle cx="36" cy="26" r="7" fill="#EF4444" />
    <path d="M36 19 L38 15" stroke="#166534" strokeWidth="2" strokeLinecap="round" />
    
    {/* Bread */}
    <rect x="42" y="16" width="10" height="20" rx="3" transform="rotate(10 47 26)" fill="#F59E0B" />
    <line x1="44" y1="20" x2="50" y2="22" stroke="#B45309" strokeWidth="1" />
    <line x1="45" y1="24" x2="51" y2="26" stroke="#B45309" strokeWidth="1" />

    {/* Cart Basket */}
    <path d="M14 34 H54 L50 50 H18 L14 34 Z" fill="#DCFCE7" stroke="#15803D" strokeWidth="3" strokeLinejoin="round" />
    <path d="M10 34 H14" stroke="#15803D" strokeWidth="3" strokeLinecap="round" />
    
    {/* Wheels */}
    <circle cx="22" cy="56" r="4" fill="#15803D" />
    <circle cx="46" cy="56" r="4" fill="#15803D" />
  </svg>
);

interface NavLinkProps {
  routeName: RouteName;
  label: string;
  currentRoute: RouteName;
  navigate: (route: RouteName) => void;
  closeMenu: () => void;
}

const NavLink: React.FC<NavLinkProps> = ({ routeName, label, currentRoute, navigate, closeMenu }) => (
  <button 
    onClick={() => {
      navigate(routeName);
      closeMenu();
    }}
    className={`text-left w-full px-4 py-2 rounded-md text-sm font-medium transition-colors ${
      currentRoute === routeName 
        ? 'bg-green-50 text-green-700' 
        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
    }`}
  >
    {label}
  </button>
);

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { cartTotal, itemCount, navigate, route } = useShop();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const categories: { name: string; route: RouteName; label: string }[] = [
    { name: Category.FruitsVeg, route: 'CAT_FRUITS', label: 'Veg & Fruits' },
    { name: Category.DairyBread, route: 'CAT_DAIRY', label: 'Dairy & Bread' },
    { name: Category.AttaRiceDal, route: 'CAT_ATTA', label: 'Atta, Rice & Dal' },
    { name: Category.MasalaOil, route: 'CAT_MASALA', label: 'Oil & Masala' },
    { name: Category.MeatFish, route: 'CAT_MEAT', label: 'Meat & Fish' },
    { name: Category.Snacks, route: 'CAT_SNACKS', label: 'Munchies' },
    { name: Category.Drinks, route: 'CAT_DRINKS', label: 'Cold Drinks' },
    { name: Category.Breakfast, route: 'CAT_BREAKFAST', label: 'Instant Food' },
    { name: Category.SweetTooth, route: 'CAT_SWEET', label: 'Sweet Tooth' },
    { name: Category.BabyPet, route: 'CAT_BABY_PET', label: 'Baby & Pet' },
    { name: Category.Household, route: 'CAT_HOUSEHOLD', label: 'Household' },
    { name: Category.PersonalCare, route: 'CAT_PERSONAL', label: 'Personal Care' },
    { name: Category.Stationery, route: 'CAT_STATIONERY', label: 'Stationery' },
    { name: Category.Electronics, route: 'CAT_ELECTRONICS', label: 'Electronics' },
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate('SEARCH_RESULTS', { query: searchQuery });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 font-sans">
      {/* Sticky Header */}
      <header className="sticky top-0 z-50 bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Left: Logo & Mobile Menu */}
            <div className="flex items-center gap-4">
              <button 
                className="lg:hidden p-2 text-gray-600"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
              <button onClick={() => navigate('HOME')} className="flex items-center gap-2 group">
                <BrandLogo />
                <span className="font-extrabold text-2xl tracking-tight text-green-900 group-hover:text-green-800 transition-colors">K - Grocers</span>
              </button>
            </div>

            {/* Center: Search */}
            <div className="hidden md:flex flex-1 max-w-2xl mx-8">
              <form onSubmit={handleSearch} className="relative w-full">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search size={18} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  className="block w-full pl-10 pr-3 py-2 border border-gray-200 rounded-lg leading-5 bg-gray-50 text-gray-900 placeholder-gray-500 focus:outline-none focus:bg-white focus:ring-1 focus:ring-green-500 focus:border-green-500 sm:text-sm"
                  placeholder="Search for 'milk', 'chips', 'vegetables'..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </form>
            </div>

            {/* Right: Actions */}
            <div className="flex items-center gap-2 sm:gap-4">
               <button 
                onClick={() => navigate('AI_CHEF')}
                className="hidden sm:flex items-center gap-1 px-3 py-1.5 bg-purple-100 text-purple-700 rounded-full text-xs font-bold hover:bg-purple-200 transition-colors"
              >
                <Sparkles size={16} />
                AI Chef
              </button>

              {itemCount > 0 ? (
                 <button 
                 onClick={() => navigate('CART')}
                 className="flex flex-col items-end bg-green-600 hover:bg-green-700 text-white px-4 py-1.5 rounded-lg transition-colors"
               >
                 <span className="text-xs font-medium">{itemCount} items</span>
                 <span className="text-sm font-bold">₹{cartTotal}</span>
               </button>
              ) : (
                <button 
                  onClick={() => navigate('CART')}
                  className="p-2 text-gray-600 hover:bg-gray-100 rounded-full"
                >
                  <ShoppingCart size={24} />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Desktop Categories Bar */}
        <nav className="hidden lg:block border-t border-gray-100 bg-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center gap-8 overflow-x-auto py-2 no-scrollbar">
                    {categories.map(cat => (
                        <button
                            key={cat.route}
                            onClick={() => navigate(cat.route)}
                            className={`whitespace-nowrap text-sm font-medium ${route.currentRoute === cat.route ? 'text-green-600' : 'text-gray-600 hover:text-gray-900'}`}
                        >
                            {cat.label}
                        </button>
                    ))}
                </div>
            </div>
        </nav>
      </header>

      {/* Mobile Menu Sidebar */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 flex lg:hidden">
          <div className="fixed inset-0 bg-black bg-opacity-25" onClick={() => setIsMobileMenuOpen(false)}></div>
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white shadow-xl overflow-y-auto">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <span className="font-bold text-lg">Menu</span>
              <button onClick={() => setIsMobileMenuOpen(false)}><X size={20}/></button>
            </div>
            <div className="p-4 space-y-2">
               <button 
                onClick={() => { navigate('AI_CHEF'); setIsMobileMenuOpen(false); }}
                className="flex items-center gap-2 w-full px-4 py-3 bg-gradient-to-r from-purple-500 to-indigo-600 text-white rounded-lg font-bold shadow-md"
              >
                <Sparkles size={18} />
                Ask AI Chef
              </button>
              <div className="h-4"></div>
              <NavLink 
                routeName="HOME" 
                label="Home" 
                currentRoute={route.currentRoute} 
                navigate={navigate} 
                closeMenu={() => setIsMobileMenuOpen(false)} 
              />
              {categories.map(cat => (
                  <NavLink 
                    key={cat.route} 
                    routeName={cat.route} 
                    label={cat.label} 
                    currentRoute={route.currentRoute} 
                    navigate={navigate} 
                    closeMenu={() => setIsMobileMenuOpen(false)}
                  />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-6">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-auto">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
           <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div>
                  <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Categories</h3>
                  <ul className="mt-4 space-y-2">
                      <li><a href="#" className="text-base text-gray-500 hover:text-gray-900">Vegetables</a></li>
                      <li><a href="#" className="text-base text-gray-500 hover:text-gray-900">Munchies</a></li>
                  </ul>
              </div>
              <div>
                  <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Company</h3>
                  <ul className="mt-4 space-y-2">
                      <li><a href="#" className="text-base text-gray-500 hover:text-gray-900">About Us</a></li>
                      <li><a href="#" className="text-base text-gray-500 hover:text-gray-900">Careers</a></li>
                  </ul>
              </div>
              <div>
                  <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Legal</h3>
                  <ul className="mt-4 space-y-2">
                      <li><a href="#" className="text-base text-gray-500 hover:text-gray-900">Privacy</a></li>
                      <li><a href="#" className="text-base text-gray-500 hover:text-gray-900">Terms</a></li>
                  </ul>
              </div>
               <div>
                  <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Connect</h3>
                  <p className="mt-4 text-base text-gray-500">
                      Get fresh groceries delivered in 10 minutes.
                  </p>
              </div>
           </div>

           <div className="mt-8 border-t border-gray-200 pt-8 text-center">
               {/* Added Contact Details as requested */}
               <div className="flex flex-col md:flex-row justify-center items-center gap-4 md:gap-8 text-gray-500 text-sm mb-6 bg-gray-50 py-4 rounded-xl">
                  <div className="flex items-center gap-2 hover:text-gray-900 transition-colors">
                    <Phone size={16} className="text-green-600" />
                    <span className="font-medium">9919670100</span>
                  </div>
                  <div className="flex items-center gap-2 hover:text-gray-900 transition-colors">
                    <Mail size={16} className="text-green-600" />
                    <span className="font-medium">kavish.sri.@gmail.com</span>
                  </div>
                  <div className="flex items-center gap-2 hover:text-gray-900 transition-colors">
                    <Instagram size={16} className="text-green-600" />
                    <span className="font-medium">@Srivastava.3898.abhi</span>
                  </div>
               </div>
               <p className="text-base text-gray-400">&copy; 2024 K - Grocers. All rights reserved.</p>
           </div>
        </div>
      </footer>
    </div>
  );
};