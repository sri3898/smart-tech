export enum Category {
  FruitsVeg = "Fruits & Vegetables",
  DairyBread = "Dairy & Bread",
  AttaRiceDal = "Atta, Rice & Dal",
  MasalaOil = "Oil, Masala & Sauces",
  Snacks = "Snacks & Munchies",
  Drinks = "Cold Drinks & Juices",
  Breakfast = "Breakfast & Instant Food",
  SweetTooth = "Sweet Tooth",
  MeatFish = "Meat, Fish & Eggs",
  Household = "Cleaning & Household",
  PersonalCare = "Personal Care",
  BabyPet = "Baby & Pet Care",
  Stationery = "Stationery & Office",
  Electronics = "Electronics & Lights"
}

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  weight: string;
  image: string;
  category: Category;
  description: string;
  rating: number;
  reviews: number;
  inStock: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  date: string;
  status: 'Pending' | 'Delivered';
}

export type RecipeResponse = {
  recipeName: string;
  description: string;
  ingredients: string[];
  instructions: string[];
};

// Custom Router Types
export type RouteName = 
  | 'HOME' 
  | 'CAT_FRUITS' 
  | 'CAT_DAIRY' 
  | 'CAT_ATTA'
  | 'CAT_MASALA'
  | 'CAT_SNACKS' 
  | 'CAT_DRINKS' 
  | 'CAT_BREAKFAST' 
  | 'CAT_SWEET'
  | 'CAT_MEAT'
  | 'CAT_HOUSEHOLD'
  | 'CAT_PERSONAL'
  | 'CAT_BABY_PET'
  | 'CAT_STATIONERY'
  | 'CAT_ELECTRONICS'
  | 'PRODUCT_DETAIL'
  | 'CART'
  | 'CHECKOUT'
  | 'SUCCESS'
  | 'AI_CHEF'
  | 'SEARCH_RESULTS';

export interface RouterState {
  currentRoute: RouteName;
  params?: Record<string, any>;
}