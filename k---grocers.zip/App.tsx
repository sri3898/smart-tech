import React from 'react';
import { ShopProvider, useShop } from './context/ShopContext';
import { Layout } from './components/Layout';
import { Category } from './types';

// Pages
import { Home } from './pages/Home';
import { CategoryPage } from './pages/CategoryPage';
import { ProductDetail } from './pages/ProductDetail';
import { Cart } from './pages/Cart';
import { Checkout } from './pages/Checkout';
import { OrderSuccess } from './pages/OrderSuccess';
import { AIChef } from './pages/AIChef';
import { SearchResults } from './pages/SearchResults';

const AppContent: React.FC = () => {
  const { route } = useShop();

  let content;
  switch (route.currentRoute) {
    case 'HOME':
      content = <Home />;
      break;
    case 'CAT_FRUITS':
      content = <CategoryPage category={Category.FruitsVeg} title="Fruits & Vegetables" />;
      break;
    case 'CAT_DAIRY':
      content = <CategoryPage category={Category.DairyBread} title="Dairy, Bread & Eggs" />;
      break;
    case 'CAT_ATTA':
      content = <CategoryPage category={Category.AttaRiceDal} title="Atta, Rice & Dal" />;
      break;
    case 'CAT_MASALA':
      content = <CategoryPage category={Category.MasalaOil} title="Oil, Masala & Sauces" />;
      break;
    case 'CAT_SNACKS':
      content = <CategoryPage category={Category.Snacks} title="Snacks & Munchies" />;
      break;
    case 'CAT_DRINKS':
      content = <CategoryPage category={Category.Drinks} title="Cold Drinks & Juices" />;
      break;
    case 'CAT_BREAKFAST':
      content = <CategoryPage category={Category.Breakfast} title="Breakfast & Instant Food" />;
      break;
     case 'CAT_SWEET':
      content = <CategoryPage category={Category.SweetTooth} title="Sweet Tooth" />;
      break;
    case 'CAT_MEAT':
      content = <CategoryPage category={Category.MeatFish} title="Meat, Fish & Eggs" />;
      break;
    case 'CAT_HOUSEHOLD':
      content = <CategoryPage category={Category.Household} title="Cleaning & Household" />;
      break;
    case 'CAT_PERSONAL':
      content = <CategoryPage category={Category.PersonalCare} title="Personal Care" />;
      break;
    case 'CAT_BABY_PET':
      content = <CategoryPage category={Category.BabyPet} title="Baby & Pet Care" />;
      break;
    case 'CAT_STATIONERY':
      content = <CategoryPage category={Category.Stationery} title="Stationery & Office" />;
      break;
    case 'CAT_ELECTRONICS':
      content = <CategoryPage category={Category.Electronics} title="Electronics & Lights" />;
      break;
    case 'PRODUCT_DETAIL':
      content = <ProductDetail />;
      break;
    case 'CART':
      content = <Cart />;
      break;
    case 'CHECKOUT':
      content = <Checkout />;
      break;
    case 'SUCCESS':
      content = <OrderSuccess />;
      break;
    case 'AI_CHEF':
      content = <AIChef />;
      break;
    case 'SEARCH_RESULTS':
      content = <SearchResults />;
      break;
    default:
      content = <Home />;
  }

  return (
    <Layout>
      {content}
    </Layout>
  );
};

const App: React.FC = () => {
  return (
    <ShopProvider>
      <AppContent />
    </ShopProvider>
  );
};

export default App;