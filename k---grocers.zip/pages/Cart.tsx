import React from 'react';
import { useShop } from '../context/ShopContext';
import { DELIVERY_FEE, FREE_DELIVERY_THRESHOLD } from '../constants';
import { Plus, Minus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';

export const Cart: React.FC = () => {
  const { cart, updateQuantity, removeFromCart, cartTotal, navigate } = useShop();

  const deliveryCharge = cartTotal > FREE_DELIVERY_THRESHOLD ? 0 : DELIVERY_FEE;
  const finalTotal = cartTotal + deliveryCharge;

  if (cart.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <div className="bg-gray-100 p-6 rounded-full mb-6">
           <ShoppingBag size={48} className="text-gray-400" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Your Cart is Empty</h2>
        <p className="text-gray-500 mb-8">Looks like you haven't added anything yet.</p>
        <button 
          onClick={() => navigate('HOME')}
          className="bg-green-600 text-white px-8 py-3 rounded-lg font-bold hover:bg-green-700 transition-colors"
        >
          Start Shopping
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row gap-8">
      {/* Cart Items List */}
      <div className="flex-grow space-y-4">
        <h1 className="text-2xl font-bold mb-4">My Cart <span className="text-gray-500 text-base font-normal">({cart.length} items)</span></h1>
        
        <div className="bg-white rounded-xl shadow-sm overflow-hidden divide-y divide-gray-100 border border-gray-200">
          {cart.map(item => (
            <div key={item.id} className="p-4 flex items-center gap-4">
              <div className="w-16 h-16 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
              </div>
              
              <div className="flex-grow">
                <h3 className="font-medium text-gray-900 line-clamp-1">{item.name}</h3>
                <p className="text-sm text-gray-500">{item.weight}</p>
                <p className="font-bold mt-1">₹{item.price}</p>
              </div>

              <div className="flex flex-col items-end gap-2">
                <div className="flex items-center bg-green-600 rounded-lg text-white px-1 py-1">
                  <button onClick={() => item.quantity === 1 ? removeFromCart(item.id) : updateQuantity(item.id, -1)} className="p-1 hover:bg-green-700 rounded"><Minus size={14} /></button>
                  <span className="font-bold text-sm mx-2 w-4 text-center">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.id, 1)} className="p-1 hover:bg-green-700 rounded"><Plus size={14} /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bill Summary */}
      <div className="w-full lg:w-96 flex-shrink-0">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-24">
          <h2 className="font-bold text-lg mb-4">Bill Details</h2>
          
          <div className="space-y-3 text-sm text-gray-600 mb-6 border-b border-gray-100 pb-6">
            <div className="flex justify-between">
              <span>Item Total</span>
              <span>₹{cartTotal}</span>
            </div>
            <div className="flex justify-between">
              <span>Delivery Fee</span>
              <span className={deliveryCharge === 0 ? "text-green-600" : ""}>
                {deliveryCharge === 0 ? "FREE" : `₹${deliveryCharge}`}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Handling Charge</span>
              <span>₹2</span>
            </div>
          </div>

          <div className="flex justify-between font-bold text-lg text-gray-900 mb-6">
            <span>To Pay</span>
            <span>₹{finalTotal + 2}</span>
          </div>

          <button 
            onClick={() => navigate('CHECKOUT')}
            className="w-full bg-green-600 text-white py-3.5 rounded-xl font-bold hover:bg-green-700 transition-colors flex items-center justify-center gap-2 shadow-green-200 shadow-lg"
          >
            Proceed to Pay
            <ArrowRight size={18} />
          </button>
          
          {deliveryCharge > 0 && (
            <p className="text-xs text-center mt-3 text-gray-500">
              Add items worth ₹{FREE_DELIVERY_THRESHOLD - cartTotal} more for free delivery.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};