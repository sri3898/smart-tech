import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CartItem, Product, RouterState, RouteName, Category } from '../types';
import { PRODUCTS } from '../constants';

interface ShopContextType {
  products: Product[];
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, delta: number) => void;
  clearCart: () => void;
  cartTotal: number;
  itemCount: number;
  
  // Custom Router State
  route: RouterState;
  navigate: (routeName: RouteName, params?: any) => void;
  getProductsByCategory: (cat: Category) => Product[];
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export const ShopProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [route, setRoute] = useState<RouterState>({ currentRoute: 'HOME' });

  // Cart Persistence with error handling for production reliability
  useEffect(() => {
    const savedCart = localStorage.getItem('kgrocers_cart');
    if (savedCart) {
      try {
        setCart(JSON.parse(savedCart));
      } catch (error) {
        console.error("Failed to parse cart from local storage:", error);
        // If parsing fails (e.g. corrupted data), reset the storage to prevent app crash
        localStorage.removeItem('kgrocers_cart');
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('kgrocers_cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.id === productId) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : item;
        }
        return item;
      });
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const clearCart = () => setCart([]);

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const navigate = (routeName: RouteName, params?: any) => {
    window.scrollTo(0, 0);
    setRoute({ currentRoute: routeName, params });
  };

  const getProductsByCategory = (cat: Category) => {
    return PRODUCTS.filter(p => p.category === cat);
  };

  return (
    <ShopContext.Provider value={{
      products: PRODUCTS,
      cart,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      cartTotal,
      itemCount,
      route,
      navigate,
      getProductsByCategory
    }}>
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) throw new Error("useShop must be used within ShopProvider");
  return context;
};