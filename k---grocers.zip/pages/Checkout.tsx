import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { MapPin, CreditCard, CheckCircle, Tag, X, ChevronRight, Lock } from 'lucide-react';

// Define the coupon tiers based on user requirements
const AVAILABLE_COUPONS = [
  { code: 'SAVE5', minOrder: 100, discount: 5, label: '₹5 OFF', description: 'On orders above ₹100' },
  { code: 'SAVE10', minOrder: 200, discount: 10, label: '₹10 OFF', description: 'On orders above ₹200' },
  { code: 'SAVE50', minOrder: 500, discount: 50, label: '₹50 OFF', description: 'On orders above ₹500' },
  { code: 'SAVE150', minOrder: 1000, discount: 150, label: '₹150 OFF', description: 'On orders above ₹1000' },
  { code: 'SAVE400', minOrder: 2500, discount: 400, label: '₹400 OFF', description: 'On orders above ₹2500' },
  { code: 'SAVE900', minOrder: 5000, discount: 900, label: '₹900 OFF', description: 'On orders above ₹5000' },
  { code: 'MEGA1000', minOrder: 5001, discount: 1000, label: '₹1000 OFF', description: 'On orders exceeding ₹5000' },
];

export const Checkout: React.FC = () => {
  const { cartTotal, navigate, clearCart } = useShop();
  const [step, setStep] = useState(1);
  
  // Coupon State
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{code: string, discount: number} | null>(null);
  const [couponMessage, setCouponMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);

  // Payment Totals
  const deliveryFee = cartTotal > 200 ? 0 : 15;
  const handlingCharge = 2;
  const totalBeforeDiscount = cartTotal + deliveryFee + handlingCharge;
  const discountAmount = appliedCoupon ? appliedCoupon.discount : 0;
  const finalTotal = Math.max(0, totalBeforeDiscount - discountAmount);

  const validateAndApplyCoupon = (code: string) => {
    const coupon = AVAILABLE_COUPONS.find(c => c.code.toUpperCase() === code.toUpperCase());
    
    if (!coupon) {
      setCouponMessage({ type: 'error', text: 'Invalid coupon code.' });
      return;
    }

    if (cartTotal < coupon.minOrder) {
      setCouponMessage({ 
        type: 'error', 
        text: `Add items worth ₹${coupon.minOrder - cartTotal} more to use this coupon.` 
      });
      return;
    }

    // Apply Coupon
    setAppliedCoupon({ code: coupon.code, discount: coupon.discount });
    setCouponCode(coupon.code);
    setCouponMessage({ type: 'success', text: `Coupon '${coupon.code}' applied successfully!` });
  };

  const handleApplyManual = (e: React.MouseEvent) => {
    e.preventDefault();
    setCouponMessage(null);
    if (!couponCode.trim()) return;
    validateAndApplyCoupon(couponCode);
  };

  const handleRemoveCoupon = () => {
      setAppliedCoupon(null);
      setCouponCode('');
      setCouponMessage(null);
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2); // Processing simulation
    setTimeout(() => {
        clearCart();
        navigate('SUCCESS');
    }, 2000);
  };

  if (step === 2) {
      return (
          <div className="flex flex-col items-center justify-center h-96">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-green-600 mb-4"></div>
              <h2 className="text-xl font-bold text-gray-800">Processing Payment...</h2>
          </div>
      );
  }

  return (
    <div className="max-w-2xl mx-auto pb-12">
      <button 
        onClick={() => navigate('CART')}
        className="mb-4 text-sm text-gray-500 hover:text-gray-900 flex items-center"
      >
        &larr; Back to Cart
      </button>
      <h1 className="text-2xl font-bold mb-6">Checkout</h1>
      
      <form onSubmit={handlePlaceOrder} className="space-y-6">
        {/* Address Section */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center gap-3 mb-4 text-gray-800">
            <MapPin className="text-green-600" />
            <h2 className="font-bold text-lg">Delivery Address</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input required type="text" placeholder="Full Name" className="p-3 border rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none" />
            <input required type="text" placeholder="Phone Number" className="p-3 border rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none" />
            <textarea required placeholder="House No, Street, Landmark" className="p-3 border rounded-lg w-full md:col-span-2 focus:ring-2 focus:ring-green-500 outline-none" rows={3}></textarea>
            <input required type="text" placeholder="Pincode" className="p-3 border rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none" />
            <input required type="text" placeholder="City" className="p-3 border rounded-lg w-full focus:ring-2 focus:ring-green-500 outline-none" />
          </div>
        </div>

        {/* Coupon Section */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
           <div className="flex items-center gap-3 mb-4 text-gray-800">
            <Tag className="text-green-600" />
            <h2 className="font-bold text-lg">Apply Coupon</h2>
          </div>

          {/* Manual Input */}
          {!appliedCoupon && (
            <div className="flex gap-3 mb-6">
                <input 
                    type="text" 
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    placeholder="Enter coupon code"
                    className="flex-grow p-3 border rounded-lg focus:ring-2 focus:ring-green-500 outline-none uppercase"
                />
                <button 
                    type="button"
                    onClick={handleApplyManual}
                    className="bg-gray-800 text-white px-6 rounded-lg font-bold hover:bg-gray-700 transition-colors"
                >
                    Apply
                </button>
            </div>
          )}

          {/* Applied Coupon Status */}
          {appliedCoupon && (
              <div className="flex items-center justify-between bg-green-50 border border-green-200 p-4 rounded-lg mb-6">
                  <div className="flex items-center gap-3">
                      <div className="bg-green-200 p-1.5 rounded-full text-green-700">
                          <CheckCircle size={16} />
                      </div>
                      <div>
                          <p className="font-bold text-green-800 uppercase tracking-wider text-sm">'{appliedCoupon.code}' APPLIED</p>
                          <p className="text-green-600 text-xs">₹{appliedCoupon.discount} savings applied to bill</p>
                      </div>
                  </div>
                  <button 
                    type="button" 
                    onClick={handleRemoveCoupon}
                    className="text-gray-400 hover:text-red-500 transition-colors p-1"
                  >
                      <X size={20} />
                  </button>
              </div>
          )}
          
          {/* Message for manual input error */}
          {couponMessage && !appliedCoupon && couponMessage.type === 'error' && (
              <p className="text-sm text-red-500 mb-4 -mt-4 ml-1">
                  {couponMessage.text}
              </p>
          )}

          {/* Available Coupons List */}
          <div className="border-t border-gray-100 pt-4">
            <h3 className="text-sm font-semibold text-gray-500 mb-3 uppercase tracking-wider">Available Coupons</h3>
            <div className="space-y-3">
              {AVAILABLE_COUPONS.map((coupon) => {
                const isEligible = cartTotal >= coupon.minOrder;
                const isApplied = appliedCoupon?.code === coupon.code;
                
                return (
                  <div 
                    key={coupon.code}
                    className={`border rounded-lg p-4 flex items-center justify-between transition-all ${
                      isApplied ? 'border-green-500 bg-green-50 ring-1 ring-green-500' : 'border-gray-200 hover:border-green-300'
                    } ${!isEligible ? 'opacity-70 bg-gray-50' : 'bg-white'}`}
                  >
                    <div className="flex-grow">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-bold text-gray-800 border border-dashed border-gray-300 px-2 py-0.5 rounded text-sm bg-gray-50">
                          {coupon.code}
                        </span>
                        {!isEligible && <Lock size={12} className="text-gray-400" />}
                      </div>
                      <p className="font-bold text-green-600">{coupon.label}</p>
                      <p className="text-xs text-gray-500">{coupon.description}</p>
                      
                      {!isEligible && (
                        <div className="mt-2 w-full max-w-[200px] bg-gray-200 rounded-full h-1.5">
                          <div 
                            className="bg-gray-400 h-1.5 rounded-full" 
                            style={{ width: `${(cartTotal / coupon.minOrder) * 100}%` }}
                          ></div>
                          <p className="text-[10px] text-red-500 mt-1 font-medium">Add ₹{coupon.minOrder - cartTotal} more</p>
                        </div>
                      )}
                    </div>

                    <div>
                      {isApplied ? (
                        <span className="text-green-600 font-bold text-sm flex items-center gap-1">
                          Applied <CheckCircle size={14} />
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => validateAndApplyCoupon(coupon.code)}
                          disabled={!isEligible}
                          className={`px-4 py-1.5 rounded text-sm font-bold transition-colors ${
                            isEligible 
                              ? 'text-green-600 bg-green-50 hover:bg-green-100 border border-green-200' 
                              : 'text-gray-400 bg-gray-100 cursor-not-allowed'
                          }`}
                        >
                          Apply
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Payment Section */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
           <div className="flex items-center gap-3 mb-4 text-gray-800">
            <CreditCard className="text-green-600" />
            <h2 className="font-bold text-lg">Payment Method</h2>
          </div>
          
          <div className="space-y-3">
            <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
              <input type="radio" name="payment" className="w-5 h-5 text-green-600" defaultChecked />
              <span className="ml-3 font-medium">UPI (Google Pay / PhonePe)</span>
            </label>
            <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
              <input type="radio" name="payment" className="w-5 h-5 text-green-600" />
              <span className="ml-3 font-medium">Credit / Debit Card</span>
            </label>
            <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
              <input type="radio" name="payment" className="w-5 h-5 text-green-600" />
              <span className="ml-3 font-medium">Cash on Delivery</span>
            </label>
          </div>
        </div>

        {/* Final Pay Button */}
        <div className="sticky bottom-4">
          <button 
            type="submit"
            className="w-full bg-green-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-green-700 transition-colors shadow-lg shadow-green-200 flex items-center justify-between px-6"
          >
            <span className="flex flex-col items-start">
              <span className="text-sm font-normal opacity-90">Total Payable</span>
              <span>₹{finalTotal}</span>
            </span>
            <span className="flex items-center gap-2 bg-green-700 px-3 py-1 rounded-lg text-sm">
              Place Order <ChevronRight size={16} />
            </span>
          </button>
        </div>
        
        <div className="text-center text-xs text-gray-400 pb-8">
             Includes ₹{handlingCharge} handling fee {deliveryFee > 0 && `+ ₹${deliveryFee} delivery fee`}
             {discountAmount > 0 && <span className="text-green-600 font-bold block mt-1"> (₹{discountAmount} discount applied)</span>}
        </div>
      </form>
    </div>
  );
};