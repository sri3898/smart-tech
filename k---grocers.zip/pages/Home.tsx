import React from 'react';
import { useShop } from '../context/ShopContext';
import { ProductCard } from '../components/ProductCard';
import { Category, RouteName } from '../types';
import { ArrowRight, Clock, ShieldCheck, Leaf, Apple, Milk, Cookie, CupSoda, Coffee, IceCream, Home as HomeIcon, Sparkles, Wheat, ChefHat, Drumstick, Baby, Pen, Zap } from 'lucide-react';

export const Home: React.FC = () => {
  const { getProductsByCategory, navigate } = useShop();

  const renderProductRow = (title: string, category: Category, route: any) => {
    const products = getProductsByCategory(category).slice(0, 4);
    return (
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-900">{title}</h2>
          <button 
            onClick={() => navigate(route)} 
            className="text-green-600 font-semibold text-sm flex items-center gap-1 hover:text-green-700"
          >
            See all <ArrowRight size={16} />
          </button>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {products.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
      </div>
    );
  };

  const categoryLinks: { title: string; icon: React.ReactNode; color: string; route: RouteName }[] = [
    { title: 'Veg & Fruits', icon: <Apple size={28} />, color: 'bg-green-100 text-green-600', route: 'CAT_FRUITS' },
    { title: 'Dairy & Bread', icon: <Milk size={28} />, color: 'bg-blue-100 text-blue-600', route: 'CAT_DAIRY' },
    { title: 'Atta & Rice', icon: <Wheat size={28} />, color: 'bg-yellow-100 text-yellow-600', route: 'CAT_ATTA' },
    { title: 'Munchies', icon: <Cookie size={28} />, color: 'bg-orange-100 text-orange-600', route: 'CAT_SNACKS' },
    { title: 'Cold Drinks', icon: <CupSoda size={28} />, color: 'bg-red-100 text-red-600', route: 'CAT_DRINKS' },
    { title: 'Meat & Fish', icon: <Drumstick size={28} />, color: 'bg-rose-100 text-rose-600', route: 'CAT_MEAT' },
    { title: 'Instant Food', icon: <Coffee size={28} />, color: 'bg-amber-100 text-amber-600', route: 'CAT_BREAKFAST' },
    { title: 'Sweet Tooth', icon: <IceCream size={28} />, color: 'bg-pink-100 text-pink-600', route: 'CAT_SWEET' },
    { title: 'Oil & Masala', icon: <ChefHat size={28} />, color: 'bg-red-50 text-red-500', route: 'CAT_MASALA' },
    { title: 'Baby & Pet', icon: <Baby size={28} />, color: 'bg-teal-100 text-teal-600', route: 'CAT_BABY_PET' },
    { title: 'Stationery', icon: <Pen size={28} />, color: 'bg-cyan-100 text-cyan-600', route: 'CAT_STATIONERY' },
    { title: 'Electronics', icon: <Zap size={28} />, color: 'bg-gray-100 text-gray-600', route: 'CAT_ELECTRONICS' },
    { title: 'Household', icon: <HomeIcon size={28} />, color: 'bg-indigo-100 text-indigo-600', route: 'CAT_HOUSEHOLD' },
    { title: 'Personal Care', icon: <Sparkles size={28} />, color: 'bg-purple-100 text-purple-600', route: 'CAT_PERSONAL' },
  ];

  return (
    <div className="space-y-8">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-green-600 to-emerald-500 rounded-2xl p-6 sm:p-10 text-white relative overflow-hidden shadow-lg">
        <div className="relative z-10 max-w-lg">
           <span className="bg-white/20 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide backdrop-blur-sm">10 Minute Delivery</span>
           <h1 className="text-3xl sm:text-5xl font-extrabold mt-4 mb-2 leading-tight">
             Fresh Groceries,<br/> Super Fast.
           </h1>
           <p className="text-green-50 text-lg mb-6">Get ₹100 OFF on your first order above ₹499. Use code: <span className="font-mono font-bold text-white bg-white/20 px-2 rounded">WELCOME100</span></p>
           <button 
             onClick={() => navigate('CAT_FRUITS')}
             className="bg-white text-green-700 font-bold py-3 px-6 rounded-lg hover:bg-green-50 transition shadow-md"
           >
             Shop Now
           </button>
        </div>
        <div className="absolute right-0 bottom-0 opacity-20 transform translate-x-1/4 translate-y-1/4">
            <svg width="400" height="400" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                <path fill="#FFFFFF" d="M45.7,-76.3C58.9,-69.3,69.1,-55.8,76.5,-41.4C83.9,-27,88.5,-11.8,86.7,2.6C84.9,17,76.8,30.6,66.7,42.3C56.6,53.9,44.6,63.6,31.1,70.7C17.6,77.7,2.7,82.1,-11.1,80.3C-24.9,78.5,-37.6,70.5,-49.1,61.5C-60.6,52.5,-71,42.5,-76.9,30.3C-82.7,18.1,-84.1,3.7,-79.7,-9.2C-75.4,-22.2,-65.4,-33.7,-54.1,-42.2C-42.8,-50.7,-30.2,-56.2,-17.8,-60.8C-5.4,-65.4,6.8,-69.1,20.5,-74.6" transform="translate(100 100)" />
            </svg>
        </div>
      </div>

      {/* Features */}
      <div className="grid grid-cols-3 gap-4 text-center py-2 border-b border-gray-100 pb-6">
        <div className="flex flex-col items-center gap-2">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-full"><Clock size={24} /></div>
          <span className="text-xs sm:text-sm font-bold text-gray-700">10 Min Delivery</span>
        </div>
        <div className="flex flex-col items-center gap-2">
          <div className="p-3 bg-green-50 text-green-600 rounded-full"><Leaf size={24} /></div>
          <span className="text-xs sm:text-sm font-bold text-gray-700">Farm Fresh</span>
        </div>
        <div className="flex flex-col items-center gap-2">
          <div className="p-3 bg-purple-50 text-purple-600 rounded-full"><ShieldCheck size={24} /></div>
          <span className="text-xs sm:text-sm font-bold text-gray-700">Quality Assured</span>
        </div>
      </div>

      {/* Shop By Category Grid */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Shop by Category</h2>
        <div className="grid grid-cols-4 md:grid-cols-7 gap-4">
          {categoryLinks.map((cat, idx) => (
            <div 
              key={idx}
              onClick={() => navigate(cat.route)}
              className="flex flex-col items-center gap-2 cursor-pointer group"
            >
              <div className={`${cat.color} p-3 md:p-4 rounded-xl shadow-sm group-hover:scale-105 transition-transform duration-300 flex items-center justify-center w-full aspect-square`}>
                {cat.icon}
              </div>
              <span className="text-xs font-medium text-center text-gray-700 leading-tight">
                {cat.title}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Product Rails */}
      {renderProductRow("Fresh Fruits & Vegetables", Category.FruitsVeg, 'CAT_FRUITS')}
      {renderProductRow("Daily Dairy & Breakfast", Category.DairyBread, 'CAT_DAIRY')}
      {renderProductRow("Atta, Rice & Dal", Category.AttaRiceDal, 'CAT_ATTA')}
      {renderProductRow("Munchies & Snacks", Category.Snacks, 'CAT_SNACKS')}
      {renderProductRow("Fresh Meat & Fish", Category.MeatFish, 'CAT_MEAT')}
    </div>
  );
};