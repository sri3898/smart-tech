import { GoogleGenAI, Type } from "@google/genai";
import { RecipeResponse } from '../types';

// Initialize Gemini AI
// Note: In a real app, ensure API_KEY is set in environment variables. 
// For this demo, we assume it is available.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateRecipe = async (query: string): Promise<RecipeResponse | null> => {
  try {
    const model = "gemini-2.5-flash";
    const prompt = `Suggest a simple recipe based on this request: "${query}". 
    Return the recipe name, a short description, a list of ingredients, and step-by-step instructions.
    Ensure the ingredients are common grocery items.`;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recipeName: { type: Type.STRING },
            description: { type: Type.STRING },
            ingredients: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING } 
            },
            instructions: {
              type: Type.ARRAY, 
              items: { type: Type.STRING }
            }
          },
          required: ["recipeName", "description", "ingredients", "instructions"]
        }
      }
    });

    let text = response.text;
    if (!text) return null;
    
    // Robust cleanup for production: remove markdown formatting if the model wraps JSON
    text = text.replace(/```json\n?|```/g, '').trim();
    
    return JSON.parse(text) as RecipeResponse;
  } catch (error) {
    console.error("Error generating recipe:", error);
    return null;
  }
};