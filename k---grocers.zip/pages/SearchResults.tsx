import React from 'react';
import { useShop } from '../context/ShopContext';
import { ProductCard } from '../components/ProductCard';
import { Search, ArrowLeft } from 'lucide-react';

export const SearchResults: React.FC = () => {
  const { products, route, navigate } = useShop();
  const query = route.params?.query || '';

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(query.toLowerCase()) ||
    p.category.toLowerCase().includes(query.toLowerCase()) ||
    p.description.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div>
      <button 
        onClick={() => navigate('HOME')}
        className="flex items-center text-gray-500 hover:text-gray-900 mb-6 transition-colors"
      >
        <ArrowLeft size={20} className="mr-1" /> Back
      </button>

      <div className="mb-6 flex items-center gap-2">
        <h1 className="text-2xl font-bold text-gray-900">Search Results</h1>
        <span className="text-gray-500">for "{query}"</span>
      </div>

      {filteredProducts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center text-red-400 mb-4">
            <Search size={36} />
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">Item Not Found</h3>
          <p className="text-gray-600 max-w-md mx-auto">
            The item searched is not available.
          </p>
          <button 
            onClick={() => navigate('HOME')}
            className="mt-6 bg-green-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-green-700 transition-colors"
          >
            Browse Categories
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {filteredProducts.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  );
};