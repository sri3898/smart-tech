import React, { useEffect } from 'react';
import { useShop } from '../context/ShopContext';
import { Check, Home } from 'lucide-react';
import confetti from 'canvas-confetti';

export const OrderSuccess: React.FC = () => {
  const { navigate } = useShop();

  useEffect(() => {
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });
  }, []);

  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-6">
        <Check size={40} strokeWidth={4} />
      </div>
      
      <h1 className="text-3xl font-bold text-gray-900 mb-2">Order Placed Successfully!</h1>
      <p className="text-gray-500 mb-8">Your groceries will arrive in 10 minutes.</p>
      
      <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm max-w-md w-full mb-8">
        <div className="flex justify-between mb-2">
          <span className="text-gray-500">Order ID</span>
          <span className="font-mono font-bold">#ORD-{Math.floor(Math.random() * 100000)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500">Est. Delivery</span>
          <span className="font-bold text-green-600">10-15 Mins</span>
        </div>
      </div>

      <button 
        onClick={() => navigate('HOME')}
        className="flex items-center gap-2 bg-gray-900 text-white px-6 py-3 rounded-lg font-bold hover:bg-gray-800 transition-colors"
      >
        <Home size={18} />
        Back to Home
      </button>
    </div>
  );
};